<?php

/**
 * Created by PhpStorm.
 * User: osman.ramazanov
 * Date: 08.06.2017
 * Time: 20:35
 */
class Admin extends User
{

}